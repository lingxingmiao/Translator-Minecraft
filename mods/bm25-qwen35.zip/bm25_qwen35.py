# -*- coding: utf-8 -*-
# ============================================================
# BM25 分词器: Qwen3.5-0.8B 分词器 (纯分词器, 不加载任何模型)
# ------------------------------------------------------------
# 分词器来源(按顺序尝试, 命中即用):
#   1. 环境变量 TRANSLATOR_QWEN35_TOKENIZER 指向的目录 / tokenizer.json
#   2. 随 zip 模组一起打包的 tokenizer.json (本文件旁边, 本包已带)
#   3. LMStudio 风格目录: models/Qwen3.5-0.8B/ (当前目录与程序目录都找)
#   4. LLM_MODEL 本身若指向 Qwen3.5 目录, 直接复用
#
# 只用 tokenizers 读 tokenizer.json, 不依赖 transformers,
# 不加载 GGUF、不需要 safetensors, 全程不下模型权重、不联网。
# 语言键: qwen35
#   用法: TranslatorConfig.INDEX_LANGUAGE / INDEX_LANGUAGE 改成 "qwen35"
# ============================================================
try:
    from TranslatorLib import Mods, os, zipfile, zipimport, eb

    默认分词器目录 = os.path.join("models", "Qwen3.5-0.8B")
    环境变量名 = "TRANSLATOR_QWEN35_TOKENIZER"
    压缩包内词表名 = "tokenizer.json"

    def 本地词表路径():
        """返回本地可用的分词器目录 / tokenizer.json, 没有就返回 None"""
        候选目录 = []
        指定路径 = os.environ.get(环境变量名)
        if 指定路径:
            if os.path.isfile(指定路径):
                return 指定路径
            候选目录.append(指定路径)
        try:
            from TranslatorConfig import Config as 运行时配置
            模型配置 = str(getattr(运行时配置, "LLM_MODEL", "") or "")
            if 模型配置 and any(标记 in os.path.basename(模型配置).lower() for 标记 in ("qwen3.5", "qwen3_5", "qwen35")):
                候选目录.append(模型配置)
        except Exception:
            pass
        根目录 = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if __file__ else os.getcwd()
        候选目录.extend([
            默认分词器目录,
            os.path.join(根目录, 默认分词器目录),
            os.path.join(os.getcwd(), 默认分词器目录),
        ])
        for 候选路径 in 候选目录:
            if not 候选路径:
                continue
            路径 = str(候选路径)
            if os.path.isfile(路径):
                if 路径.lower().endswith(".json"):
                    return 路径
                continue
            if os.path.isfile(os.path.join(路径, 压缩包内词表名)):
                return os.path.join(路径, 压缩包内词表名)
        return None

    def 随包词表数据():
        """读取打包进 zip 模组的 tokenizer.json, 没有就返回 None"""
        当前位置 = globals().get("__file__")
        if not 当前位置:
            return None
        规范路径 = 当前位置.replace("\\", "/")
        try:
            压缩包路径 = None
            if ".zip/" in 规范路径:
                压缩包路径 = 规范路径.split(".zip/", 1)[0] + ".zip"
            if 压缩包路径 and os.path.isfile(压缩包路径):
                with zipfile.ZipFile(压缩包路径) as 压缩包:
                    if 压缩包内词表名 in 压缩包.namelist():
                        return 压缩包.read(压缩包内词表名)
        except Exception:
            pass
        try:
            import mods as 模组包
            for 搜索项 in list(getattr(模组包, "__path__", [])):
                if not str(搜索项).lower().endswith(".zip") or not os.path.isfile(str(搜索项)):
                    continue
                try:
                    读取器 = zipimport.zipimporter(str(搜索项))
                    return 读取器.get_data(压缩包内词表名)
                except Exception:
                    continue
        except Exception:
            pass
        return None

    def 构建分词器():
        try:
            from tokenizers import Tokenizer
        except ImportError as 错误:
            raise RuntimeError("缺 tokenizers 库: 请用打包自带的 TranslatorPack 环境启动(pip install tokenizers)") from 错误
        来源 = 本地词表路径()
        if 来源 is not None:
            return Tokenizer.from_file(来源)
        数据 = 随包词表数据()
        if 数据:
            return Tokenizer.from_str(数据.decode("utf-8"))
        raise FileNotFoundError(
            "找不到 Qwen3.5-0.8B 分词器(本模组不联网下载): 请把 tokenizer.json 放进 %s 目录, "
            "或用环境变量 %s 指向它" % (默认分词器目录, 环境变量名)
        )

    def 特殊编号集合(分词器):
        """收集不该进 BM25 词表的特殊 token 编号"""
        编号 = set()
        for 属性 in ("bos_token_id", "eos_token_id", "pad_token_id", "unk_token_id", "sep_token_id", "cls_token_id"):
            try:
                取值 = getattr(分词器, 属性, None)
                if isinstance(取值, int) and 取值 >= 0:
                    编号.add(取值)
            except Exception:
                pass
        特殊标记 = set()
        for 属性 in ("bos_token", "eos_token", "pad_token", "unk_token"):
            try:
                取值 = getattr(分词器, 属性, None)
                if isinstance(取值, str) and 取值:
                    特殊标记.add(取值)
            except Exception:
                pass
        try:
            词条表 = 分词器.get_added_tokens_decoder() if hasattr(分词器, "get_added_tokens_decoder") else None
            for 编号值, 内容 in (词条表 or {}).items():
                if bool(getattr(内容, "special", False)) or getattr(内容, "content", None) in 特殊标记:
                    编号.add(编号值)
        except Exception:
            pass
        return 编号

    def 调用分词器(分词器, 文本列表):
        try:
            编码结果 = 分词器.encode_batch(list(文本列表), add_special_tokens=False)
        except TypeError:
            编码结果 = 分词器.encode_batch(list(文本列表))
        if 编码结果 and hasattr(编码结果[0], "ids"):
            return [list(单项.ids) for 单项 in 编码结果]
        return [list(单项) for 单项 in 编码结果]

    分词器缓存 = {"实例": None, "特殊编号": set(), "失败": False}

    def 取分词器():
        if 分词器缓存["实例"] is None and not 分词器缓存["失败"]:
            try:
                分词器缓存["实例"] = 构建分词器()
                分词器缓存["特殊编号"] = 特殊编号集合(分词器缓存["实例"])
            except Exception:
                分词器缓存["失败"] = True
                eb.print_exc()
        return 分词器缓存["实例"]

    @Mods().注册分词器("qwen35")
    def Tokenizer(texts: list) -> list:
        分词器 = 取分词器()
        if 分词器 is None:
            raise RuntimeError("Qwen3.5 分词器加载失败, 往上翻看具体报错; 可用环境变量 %s 指定分词器路径" % 环境变量名)
        编号列表 = 调用分词器(分词器, texts)
        特殊编号 = 分词器缓存["特殊编号"]
        原始编号 = os.environ.get("TRANSLATOR_QWEN35_RAW", "") not in ("", "0")
        结果 = []
        for 单项 in 编号列表:
            词列表 = []
            for 编号 in 单项:
                if 特殊编号 and 编号 in 特殊编号:
                    continue
                if 原始编号:
                    词列表.append(编号)
                    continue
                词文本 = 分词器.id_to_token(int(编号))
                词文本 = (词文本 if 词文本 is not None else "t%d" % 编号).replace("Ġ", "").replace("Ċ", "\n").strip()
                词列表.append(词文本 if 词文本 else "∅")
            结果.append(词列表)
        return 结果
except Exception:
    try:
        from TranslatorLib import eb
        eb.print_exc()
    except Exception:
        pass
